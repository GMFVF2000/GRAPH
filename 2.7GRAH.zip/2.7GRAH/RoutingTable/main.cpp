#include <iostream>
#include "Models/Graph.h"

int main() {

    /**
     *Approach OOP
     */
    std::string workPlace="/home/abou/Bureau/COURSM1IOT/AdvancedAlgorithms/Exercice/2.7GRAH/RoutingTable/data/";

   /*
    * bizar
    */
    //AdjancyMatrix::Graph<int> network(workPlace+"mat7.txt",workPlace+"cost7.txt");



    //AdjancyMatrix::Graph<int> network(workPlace+"mat2.txt",workPlace+"cost2.txt");
    AdjancyMatrix::Graph<int> network(workPlace+"mat3.txt",workPlace+"cost3.txt");
    //AdjancyMatrix::Graph<int> network(workPlace+"mat5.txt",workPlace+"cost5.txt");
   //AdjancyMatrix::Graph<int> network(workPlace+"mat6.txt",workPlace+"cost6.txt");
    //AdjancyMatrix::Graph<int> network(workPlace+"adjacency",workPlace+"cost");
  // AdjancyMatrix::Graph<int> network(workPlace+"mat1.txt",workPlace+"cost1.txt");
    //AdjancyMatrix::Graph<int> network(workPlace+"mat4.txt",workPlace+"cost4.txt");

    /***************************************************/

    network.getShortestMatrix();
    network.displayWarshallRslt();
    /**
     * durant the test in class i call this function before call getShortestMatrix() so that is a reason for my mistake
     * Now is Ok 
     */
    network.path(2,3);

    /***************************************************/
    network.DFS2();
    network.displaySCC();

//    network.displaySCC();


    /***************************************************/
    network.makeClusterMatrix();
    network.displayClusterMatrix();


    /*********************Extra*******************/

    //network.path(0,5);
    //network.displayPostOrder();
    /**Give the set of neighbors fof 2**/
    //network.neighbors(2);
    //...
    return 0;
}
