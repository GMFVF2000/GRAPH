//
// Created by abou on 13/10/2019.
//

#ifndef DATASTRUCTURE_GRAPH_H
#define DATASTRUCTURE_GRAPH_H

#include <set>
#include <assert.h>
#include <vector>
#include <fstream>
#include <limits>
#include <algorithm>

namespace AdjancyMatrix {
    const int INF = 1e9 + 5;

    template<class Type>
    class Graph {
    private:
        static const int MAXIMUM = 30;
        bool initialised = false;
    public:
        //TODO change array with vector to get dynamic size

        bool adjacencyMatrix[MAXIMUM][MAXIMUM];
        bool adjacencyMatrixReverse[MAXIMUM][MAXIMUM];


        std::vector<std::vector<int>> clusterMactrix;
        int costMatrix[MAXIMUM][MAXIMUM];
        std::vector<std::vector<int> > warshallRslt;
        Type pred[MAXIMUM][MAXIMUM];
        Type PO[MAXIMUM];
        int SCC[MAXIMUM];
        bool M[MAXIMUM];
        int nbrItem = 0;
        Type labels[MAXIMUM];
        int manyVertices = 0;
    public:
        Graph();
        Graph(std::string fileAdjancyMatrix, std::string fileCostMatrix);
        ~Graph();
        void initArray();
        void addVertex(const Type &value);
        void addEdge(int source, int target);
        void removeEdge(int source, int target);
        Type &operator[](int vertex);
        Type &operator[](int vertex) const;
        int size();
        bool isEdge(int source, int target);
        std::set<Type> neighbors(int vertex);
        void print();
        static const int getMaximum();
        const Type *getLabels() const;
        int getManyVertices() const;
        const Type getLabel(int item);
        void getShortestMatrix();
        int getShortestPathFromTo(int source, int destination);
        void displayCostMatrix() const;
        void displayAdjacencyMatrix() const;
        void displayWarshallRslt();
        void DFS2();
        std::set<Type> neighborsReverse(int vertex);
        void displayPostOrder();
        void displaySCC();
        void makeClusterMatrix();
        std::set<Type> clusterNode(int cluster);
        void displayClusterMatrix();
        void path(int source, int target);

        void DFS1();
    private :
        void DFSRec1(int s, int &counter);
        void DFRec2(int s, int &counter);


        void pathUtils(int source, int target);
    };


    template<class Type>
    const int Graph<Type>::MAXIMUM;

    template<class Type>
    Graph<Type>::Graph() {
        initArray();
    };

    template<class Type>
    Graph<Type>::Graph(std::string fileAdjancyMatrix, std::string fileCostMatrix) {
        initArray();
        std::string line;
        std::ifstream input;
        input.open(fileAdjancyMatrix);
        if (!input) {
            std::cout << "Pas possible d'ouvrir le fichier " <<fileAdjancyMatrix<< std::endl;
            exit(1);
        }
        std::getline(input, line, '\n');
        nbrItem = stoi(line);
        manyVertices = nbrItem;
        int index, i = 0;
        while (std::getline(input, line, '\n')) {
            index = 0;
            for (int j = 0; j < nbrItem; ++j) {
                if (line[index] != '0') {
                    adjacencyMatrix[i][j] = true;
                }
                index = index + 2;
            }
            i++;
        }
        input.close();
        input.open(fileCostMatrix);
        if (!input) {
            std::cout << "Pas possible d'ouvrir le fichier " <<fileCostMatrix<< std::endl;
            exit(1);
        }

        std::getline(input, line, '\n');
        nbrItem = stoi(line);
        index = 0, i = 0;
        while (std::getline(input, line, '\n')) {
            index = 0;
            for (int j = 0; j < nbrItem; ++j) {
                costMatrix[i][j] = line[index] - '0';
                index = index + 2;
            }
            i++;
        }
        input.close();
    };

    template<class Type>
    Graph<Type>::~Graph() {

    };
    template<class Type>
    void Graph<Type>::addVertex(const Type &value) {
        assert(size() < MAXIMUM);
        int newVertexNumber = manyVertices;
        manyVertices++;
        for (int otherVertexNumber = 0; otherVertexNumber <= manyVertices; ++otherVertexNumber) {
            adjacencyMatrix[otherVertexNumber][newVertexNumber] = false;
            adjacencyMatrix[newVertexNumber][otherVertexNumber] = false;
        }
        labels[newVertexNumber] = value;
    }

    template<class Type>
    void Graph<Type>::addEdge(int source, int target) {
        assert(source <= size() && target <= size());
        adjacencyMatrix[source][target] = true;
    }

    template<class Type>
    bool Graph<Type>::isEdge(int source, int target) {
        assert(source <= size() && target <= size());
        bool isAnEdge = false;
        isAnEdge = adjacencyMatrix[source][target];
        return isAnEdge;
    }

    template<class Type>
    Type &Graph<Type>::operator[](int vertex) {
        assert(vertex < size());
        return labels[vertex];
    }

    template<class Type>
    Type &Graph<Type>::operator[] (int vertex) const {
        assert(vertex < size());
        return labels[vertex];
    }

    template<class Type>
    std::set<Type> Graph<Type>::neighbors(int vertex) {
        assert(vertex < size());
        std::set<int> vertexNeighbors;
        for (int index = 0; index < size(); ++index) {
            if (adjacencyMatrix[vertex][index]) {
                vertexNeighbors.insert(index);
            }
        }
        return vertexNeighbors;
    }

    template<class Type>
    std::set<Type> Graph<Type>::neighborsReverse(int vertex) {
        assert(vertex < size());
        std::set<int> vertexNeighbors;
        for (int index = 0; index < size(); ++index) {
            if (adjacencyMatrix[index][vertex]) {
                vertexNeighbors.insert(index);
            }
        }
        return vertexNeighbors;
    }


    template<class Type>
    void Graph<Type>::removeEdge(int source, int target) {
        assert(source < size() && target < size());
        adjacencyMatrix[source][target] = false;

    }


    template<class Type>
    int Graph<Type>::size() {
        return manyVertices;
    }

    template<class Type>
    void Graph<Type>::initArray() {
        for (int i = 0; i < MAXIMUM; ++i) {
            for (int j = 0; j < MAXIMUM; ++j) {
                adjacencyMatrix[i][j] = false;
                adjacencyMatrixReverse[i][j] = false;
                costMatrix[i][j] = 0;

            }
        }
        for (int j = 0; j < MAXIMUM; ++j) {
            M[j] = false;
            SCC[j] = 0;
            PO[j] = 0;

        }


    }

    template<class Type>
    void Graph<Type>::getShortestMatrix() {
       warshallRslt.resize(nbrItem);
        for (int i = 0; i < nbrItem; ++i) {
            warshallRslt[i].resize(nbrItem);
            for (int j = 0; j < nbrItem; ++j) {


                pred[i][j]=-1;



                if (costMatrix[i][j] != 0)
                    warshallRslt[i][j] = costMatrix[i][j];
                else
                    warshallRslt[i][j] = INF;
                if (i == j) {
                    warshallRslt[i][j] = 0;
                }
            }
        }
        /**
         * the core of algorithm
         */









        for (int k = 0; k < nbrItem; ++k) {
            for (int i = 0; i < nbrItem; ++i) {
                for (int j = 0; j < nbrItem; ++j) {
                    if (warshallRslt[i][k] != INF and warshallRslt[k][j] != INF) {
                        if (warshallRslt[i][j] > warshallRslt[i][k] + warshallRslt[k][j]) {
                            warshallRslt[i][j] = warshallRslt[i][k] + warshallRslt[k][j];
                            pred[i][j]=k;
                        }
                    }
                }
            }

        }
    }

    template<class Type>
    int Graph<Type>::getShortestPathFromTo(int source, int destination) {
        if (initialised == false) {
            getShortestMatrix();
        }
        if (warshallRslt[source - 1][destination - 1] >= INF)
            std::cout << "INF" << "  ";
        else
            std::cout << warshallRslt[source - 1][destination - 1] << "  ";
        return warshallRslt[source - 1][destination - 1];

    }


    template<class Type>
    const int Graph<Type>::getMaximum() {
        return MAXIMUM;
    }


    template<class Type>
    const Type *Graph<Type>::getLabels() const {
        return labels;
    }

    template<class Type>
    const Type Graph<Type>::getLabel(int item) {
        return labels[item];
    }


    template<class Type>
    int Graph<Type>::getManyVertices() const {
        return manyVertices;
    }

    template<class Type>
    void Graph<Type>::displayCostMatrix() const {
        for (int i = 0; i < nbrItem; ++i) {
            for (int j = 0; j < nbrItem; ++j) {
                std::cout << costMatrix[i][j] << "  ";
            }
            std::cout << std::endl;
        }
    }

    template<class Type>
    void Graph<Type>::displayAdjacencyMatrix() const {
        std::cout << std::endl;

        std::cout << "The adjacency matrix " << std::endl;
        for (int i = 0; i < nbrItem; ++i) {
            for (int j = 0; j < nbrItem; ++j) {
                std::cout << adjacencyMatrix[i][j] << "  ";
            }
            std::cout << std::endl;
        }
    }

    template<class Type>
    void Graph<Type>::displayWarshallRslt() {
        std::cout << std::endl;
        std::cout << "The routing table is: " << std::endl;

        if (initialised == false) {
            getShortestMatrix();
        }


        for (int i = 0; i < nbrItem; ++i) {
            for (int j = 0; j < nbrItem; ++j) {
                if (warshallRslt[i][j] >= INF)
                    std::cout << "∞" << "     ";
                else
                    std::cout << warshallRslt[i][j] << "     ";
            }
            std::cout << std::endl;
        }
    }

    template<class Type>
    void Graph<Type>::DFS1() {

        for (int j = 0; j < nbrItem; ++j) {
            PO[j]=0;
        }
        int counter = 0;

        bool flag= true;
        while (flag){
        flag=false;
            for (int i = 0; i < nbrItem; i++) {
                if (M[i] == false && PO[i] == 0) {
                    DFSRec1(i, counter);
                    flag=true;
                }
            }
        }



    }

    template<class Type>
    void Graph<Type>::DFSRec1(int s, int &counter) {
        M[s] = true;
        std::set<int> neighbors = this->neighbors(s);
        for (int i: neighbors) {
            if (M[i] == false) {
                DFSRec1(i, counter);
                counter++;
                PO[s] = counter;
            }
        }
    }

    template<class Type>
    void Graph<Type>::DFS2() {
        DFS1();
        for (int j = 0; j < nbrItem; ++j) {
            M[j] = false;
            SCC[j] = 0;
        }

        int counter = 0;
        int tmp = 0;
        int vertex = 0;

       do  {
            tmp = -1;
            for (int k = 0; k < nbrItem; ++k) {
                if (tmp < PO[k] && SCC[k] == 0) {
                    tmp = PO[k];
                    vertex = k;
                   }
            }
            if (tmp != -1) {
                counter++;
                SCC[vertex] = counter;
                for (int item:this->neighborsReverse(vertex)) {
                    if (!M[item]) {
                        DFRec2(item, counter);
                    }
                }
            }
        } while (tmp != -1);
    }

    template<class Type>
    void Graph<Type>::DFRec2(int s, int &counter) {
        M[s] = true;
        SCC[s] = counter;
        std::set<int> neighbors = neighborsReverse(s);
        for (int item: neighbors) {
            if (M[item] == false) {
                DFRec2(item, counter);
                SCC[s] = counter;

            }
        }
    }

    template<class Type>
    void Graph<Type>::displayPostOrder() {
        for (int i = 0; i < nbrItem; ++i) {
            std::cout << "The post-order " << i+1 << " : " << PO[i] << std::endl;

        }
    }

    template<class Type>
    void Graph<Type>::displaySCC() {

        std::cout << std::endl;
        int res = 1;
        /**
         * res contents the number of the cluster
         */
        for (int i = 1; i < nbrItem; i++) {
            int j = 0;
            for (j = 0; j < i; j++)
                if (SCC[i] == SCC[j])
                    break;
            if (i == j)
                res++;
        }


        std::cout<< "There are "<< res <<" clusters: "<<std::endl;
        std::cout << std::endl;

        for (int i = 1; i <= res+1; ++i) {
            std::cout<< "Cluster "<<i<< ": {";
            for (int j = 0; j < nbrItem; ++j) {
                if (SCC[j]==i)
                    std::cout<< j+1<<",";
            }
            std::cout<< "}"<<std::endl;

        }

       }
    template<class Type>
    void Graph<Type>::makeClusterMatrix() {

        int res = 1;
        for (int i = 1; i < nbrItem; i++) {
            int j = 0;
            for (j = 0; j < i; j++)
                if (SCC[i] == SCC[j])
                    break;
            if (i == j)
                res++;
        }

        clusterMactrix.resize(res);
        for (int k = 0; k < res; ++k) {
            clusterMactrix[k].resize(res);
        }

        for (int m = 0; m <nbrItem ; ++m) {
            for (int i = 0; i <nbrItem ; ++i) {
                if(SCC[m]!=SCC[i]){
                    if(isEdge(m,i))
                    {
                        clusterMactrix[SCC[i]-1] [SCC[m]-1]+=1;
                    }
                }
            }
        }




    }

    template<class Type>
    std::set<Type> Graph<Type>::clusterNode(int cluster){

        std::set<int> items;
        for (int i = 0; i <nbrItem ; ++i) {
            if(SCC[i]){
              items.insert(i);
            }
        }
        return items;
    };

    template<class Type>
    void Graph<Type>::displayClusterMatrix(){
        std::cout << std::endl;
        std::cout<<"\tThe matrix of cluster: "<<std::endl;
        std::cout<<std::endl;
        for(int i =0; i<clusterMactrix.size();i++){
            for (int j = 0; j < clusterMactrix.size(); ++j) {
               std::cout << "\t"<<clusterMactrix[i][j]<<" ";
            }
        std::cout<<std::endl;
        }
    };
    template<class Type>
    void Graph<Type>::path(int source, int target){

        std::cout << "The path from "<< source << " to " << target << " is : "<< std::endl;
        pathUtils(source, target);
    }

    template<class Type>
    void Graph<Type>::pathUtils(int source, int target){


        if(pred[source][target]==-1){
            std::cout<< source <<"----"<< target<<std::endl; ;
        }else
        {
            pathUtils(source, pred[source][target]);
            pathUtils(pred[source][target], target);
        }
    }


}
#endif //DATASTRUCTURE_GRAPH_H
