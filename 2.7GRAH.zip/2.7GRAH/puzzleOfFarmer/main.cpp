#include <iostream>
#include <filesystem>
int main() {
    std::cout << "Hello, World!" << std::endl;

    G.addNode(1,25,20,"FWGC","_");
    G.addNode(2,375,20,"WC","FG");
    G.addLInk(1,2,'G');
    return 0;
}