//
// Created by abou on 07/10/2019.
//

#ifndef PUZZLEOFFARMER_FWCG_GRAPH_H
#define PUZZLEOFFARMER_FWCG_GRAPH_H

#include <istream>
#include <vector>

class FWCG_node;
class FWCG_link;
using namespace std;

class FWCG_Graph{

    vector<FWCG_node*> nodes;
    vector<FWCG_link*> links;


public:
    FWCG_Graph();
    void addNode(int id,double x,double y,const string &lb, const string &rb );
    void addLink(int idLeft, int addLeft, char passenger);
    FWCG_node * findNode(int id);

};



class FWCG_node{
public :
    int id;
    double pos[2];
    string leftBank;
    string rightBank;

public:
    FWCG_node(int _id,double _x,double _y,const string &lb,const string &rb):
    id(_id),leftBank(lb),rightBank(rb){
        pos[0]=_x;
        pos[1]=_y;
        pos[2]=0;
    }
    void addLink(FWCG_link){

    }


};

class FWCG_link{
public:
    char passenger;
    FWCG_node *left;
    FWCG_node *right;
    FWCG_link(FWCG_node *ptr1,FWCG_node *ptr2,char _passenger){

    }
};


void FWCG_Graph::addNode(int id, double x, double y, const string &lb, const string &rb) {
    FWCG_node * newNode= new FWCG_node(id,x,y,lb,rb);
    nodes.push_back(newNode);
}

void FWCG_Graph::addLink(int idLeft, int idRight, char passenger) {
    FWCG_node *leftNode= findNode(idLeft);
    FWCG_node *rightNode=findNode(idRight);

    FWCG_link *newLink1=new FWCG_link(leftNode,rightNode,passenger);
    FWCG_link *newLink2=new FWCG_link(rightNode,leftNode,passenger);
    links.push_back(newLink1);
    links.push_back(newLink2);

}


FWCG_node *FWCG_Graph::findNode(int id){

auto iterator = nodes.begin();
while (iterator!=nodes.end() && (*iterator)->id!=id)
{
    iterator++;
}
    return (iterator!=nodes.end()?(*iterator): nullptr);
}


#endif //PUZZLEOFFARMER_FWCG_GRAPH_H
