#include <iostream>
#include "Models/Graph.h"

int main() {

    /**
     *Approach OOP
     */
    std::string workPlace="/home/abou/Bureau/COURSM1IOT/AdvancedAlgorithms/Exercice/2.7GRAH/RoutingTable/data/";

    AdjancyMatrix::Graph<int> network(workPlace+"mat3.txt",workPlace+"cost3.txt");

    //AdjancyMatrix::Graph<int> network(workPlace+"adjacency",workPlace+"cost");

    /***************************************************/

    network.getShortestMatrix();
    network.displayWarshallRslt();

    /***************************************************/
    network.DFS2();
    network.displaySCC();


    /***************************************************/
    network.makeClusterMatrix();
    network.displayClusterMatrix();


    /*********************Extra*******************/

    //network.path(0,5);
    //network.displayPostOrder();
    /**Give the set of neighbors fof 2**/
    //network.neighbors(2);
    //...
    return 0;
}
